# FellaClient

Modern client-side Fabric mod for **Minecraft Java Edition 1.21.11**.

- Press **G** to open the dark ClickGUI (does **not** pause the game)
- Categories: Combat, Movement, Visuals, BaseFinding, Render
- Working modules: Sprint, Fullbright, FPS display, Keystrokes
- Modular code – easy to add more features

## How to get the compiled JAR (Android-friendly)

### Method 1 – GitHub Actions (recommended, no PC needed)

1. Create a free GitHub account (if you don’t have one).
2. Create a **new repository** (name it e.g. `FellaClient`).
3. Upload **all** the files from this project into that repository  
   (on phone you can use the GitHub mobile app or the website “Upload files”).
4. Go to the **Actions** tab of your repository.
5. Click the workflow **“Build FellaClient”** → **Run workflow**.
6. When it finishes (green check), open the run → scroll to **Artifacts** → download **FellaClient**.
7. Inside the zip you will find `fellaclient-1.0.0.jar` (rename to `FellaClient.jar` if you like).

### Method 2 – On a computer

```bash
./gradlew build
```
The JAR appears in `build/libs/`.

## Installation

1. Install Fabric Loader for Minecraft 1.21.11.
2. Put **Fabric API** (for 1.21.11) into the `mods` folder.
3. Put `FellaClient.jar` into the same `mods` folder.
4. Launch the game and press **G**.

## License

MIT / free to use and modify.
