package com.fellaclient.client.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Minecraft.class)
public class MinecraftClientMixin {
    // Placeholder for future mixins if needed
}
