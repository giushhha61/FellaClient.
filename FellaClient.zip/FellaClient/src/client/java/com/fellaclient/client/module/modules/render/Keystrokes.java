package com.fellaclient.client.module.modules.render;

import com.fellaclient.client.module.Category;
import com.fellaclient.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

public class Keystrokes extends Module {
    public Keystrokes() {
        super("Keystrokes", "Shows WASD and mouse buttons", Category.RENDER);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        int x = 4;
        int y = 20;
        int size = 20;
        int gap = 2;

        // W
        drawKey(graphics, x + size + gap, y, size, "W", isKeyDown(GLFW.GLFW_KEY_W));
        // A S D
        drawKey(graphics, x, y + size + gap, size, "A", isKeyDown(GLFW.GLFW_KEY_A));
        drawKey(graphics, x + size + gap, y + size + gap, size, "S", isKeyDown(GLFW.GLFW_KEY_S));
        drawKey(graphics, x + 2 * (size + gap), y + size + gap, size, "D", isKeyDown(GLFW.GLFW_KEY_D));
        // Space
        drawKey(graphics, x, y + 2 * (size + gap), size * 3 + gap * 2, "SPACE", isKeyDown(GLFW.GLFW_KEY_SPACE));
        // LMB RMB
        drawKey(graphics, x, y + 3 * (size + gap), size + gap / 2 + size / 2, "LMB", isMouseDown(0));
        drawKey(graphics, x + size + gap + size / 2, y + 3 * (size + gap), size + gap / 2 + size / 2, "RMB", isMouseDown(1));
    }

    private void drawKey(GuiGraphics graphics, int x, int y, int width, String label, boolean pressed) {
        int bg = pressed ? 0xAA00AA00 : 0xAA222222;
        int border = pressed ? 0xFF00FF00 : 0xFF555555;
        graphics.fill(x, y, x + width, y + 18, bg);
        graphics.renderOutline(x, y, width, 18, border);
        int textWidth = mc.font.width(label);
        graphics.drawString(mc.font, label, x + (width - textWidth) / 2, y + 5, 0xFFFFFF, false);
    }

    private boolean isKeyDown(int key) {
        long window = mc.getWindow().getWindow();
        return GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }

    private boolean isMouseDown(int button) {
        long window = mc.getWindow().getWindow();
        return GLFW.glfwGetMouseButton(window, button) == GLFW.GLFW_PRESS;
    }
}
