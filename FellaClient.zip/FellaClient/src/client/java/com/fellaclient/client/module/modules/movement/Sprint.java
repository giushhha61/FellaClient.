package com.fellaclient.client.module.modules.movement;

import com.fellaclient.client.module.Category;
import com.fellaclient.client.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically sprints when moving forward", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.input != null) {
            if (mc.player.input.forwardImpulse > 0 && !mc.player.isShiftKeyDown() && !mc.player.horizontalCollision) {
                mc.player.setSprinting(true);
            }
        }
    }
}
