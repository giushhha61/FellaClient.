package com.fellaclient.client.gui;

import com.fellaclient.client.FellaClient;
import com.fellaclient.client.module.Category;
import com.fellaclient.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private Category selectedCategory = Category.COMBAT;
    private int scrollOffset = 0;
    private final int sidebarWidth = 100;
    private final int panelX = 120;
    private final int panelY = 40;
    private final int panelWidth = 200;
    private final int moduleHeight = 24;

    public ClickGuiScreen() {
        super(Component.literal("FellaClient"));
    }

    @Override
    public boolean isPauseScreen() {
        return false; // Does not pause the game
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        // Semi-transparent dark background
        graphics.fill(0, 0, this.width, this.height, 0x99000000);

        // Main panel background
        int mainX = 20;
        int mainY = 20;
        int mainW = 340;
        int mainH = this.height - 40;
        drawRoundedRect(graphics, mainX, mainY, mainW, mainH, 0xFF1A1A1A);
        drawBorder(graphics, mainX, mainY, mainW, mainH, 0xFF333333);

        // Title
        graphics.drawCenteredString(this.font, "FellaClient", mainX + mainW / 2, mainY + 8, 0xFFFFFF);

        // Sidebar
        int sideX = mainX + 5;
        int sideY = mainY + 30;
        int sideH = mainH - 40;
        drawRoundedRect(graphics, sideX, sideY, sidebarWidth, sideH, 0xFF121212);

        // Categories
        int catY = sideY + 5;
        for (Category cat : Category.values()) {
            boolean selected = cat == selectedCategory;
            boolean hovered = mouseX >= sideX && mouseX <= sideX + sidebarWidth &&
                    mouseY >= catY && mouseY <= catY + 22;

            int bgColor = selected ? 0xFF2A5A8A : (hovered ? 0xFF2A2A2A : 0xFF1A1A1A);
            graphics.fill(sideX + 2, catY, sideX + sidebarWidth - 2, catY + 22, bgColor);
            if (selected) {
                graphics.fill(sideX + 2, catY, sideX + 5, catY + 22, 0xFF4A9EFF);
            }
            int textColor = selected || hovered ? 0xFFFFFF : 0xAAAAAA;
            graphics.drawString(this.font, cat.getName(), sideX + 12, catY + 7, textColor, false);
            catY += 26;
        }

        // Modules panel
        int modX = mainX + sidebarWidth + 15;
        int modY = mainY + 30;
        int modW = mainW - sidebarWidth - 25;
        int modH = mainH - 40;
        drawRoundedRect(graphics, modX, modY, modW, modH, 0xFF121212);

        List<Module> modules = FellaClient.INSTANCE.getModuleManager().getModulesByCategory(selectedCategory);
        int startY = modY + 5 - scrollOffset;
        int idx = 0;
        for (Module mod : modules) {
            int my = startY + idx * (moduleHeight + 4);
            if (my + moduleHeight < modY || my > modY + modH) {
                idx++;
                continue;
            }

            boolean hovered = mouseX >= modX + 5 && mouseX <= modX + modW - 5 &&
                    mouseY >= my && mouseY <= my + moduleHeight;

            int bg = mod.isEnabled() ? 0xFF1A3A1A : (hovered ? 0xFF2A2A2A : 0xFF1E1E1E);
            graphics.fill(modX + 5, my, modX + modW - 5, my + moduleHeight, bg);

            // Toggle indicator
            int indicatorColor = mod.isEnabled() ? 0xFF00CC66 : 0xFF555555;
            graphics.fill(modX + 8, my + 6, modX + 14, my + moduleHeight - 6, indicatorColor);

            int nameColor = mod.isEnabled() ? 0xFF00FF88 : 0xFFCCCCCC;
            graphics.drawString(this.font, mod.getName(), modX + 20, my + 8, nameColor, false);

            // Status text
            String status = mod.isEnabled() ? "ON" : "OFF";
            int statusColor = mod.isEnabled() ? 0xFF00FF88 : 0xFF888888;
            int statusWidth = this.font.width(status);
            graphics.drawString(this.font, status, modX + modW - 15 - statusWidth, my + 8, statusColor, false);

            idx++;
        }

        // Footer
        graphics.drawCenteredString(this.font, "Press G to close  |  Scroll to navigate", mainX + mainW / 2, mainY + mainH - 15, 0x666666);

        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int mainX = 20;
            int mainY = 20;
            int sideX = mainX + 5;
            int sideY = mainY + 30;

            // Category clicks
            int catY = sideY + 5;
            for (Category cat : Category.values()) {
                if (mouseX >= sideX && mouseX <= sideX + sidebarWidth &&
                        mouseY >= catY && mouseY <= catY + 22) {
                    selectedCategory = cat;
                    scrollOffset = 0;
                    return true;
                }
                catY += 26;
            }

            // Module clicks
            int modX = mainX + sidebarWidth + 15;
            int modY = mainY + 30;
            int modW = 340 - sidebarWidth - 25;
            List<Module> modules = FellaClient.INSTANCE.getModuleManager().getModulesByCategory(selectedCategory);
            int startY = modY + 5 - scrollOffset;
            int idx = 0;
            for (Module mod : modules) {
                int my = startY + idx * (moduleHeight + 4);
                if (mouseX >= modX + 5 && mouseX <= modX + modW - 5 &&
                        mouseY >= my && mouseY <= my + moduleHeight) {
                    mod.toggle();
                    return true;
                }
                idx++;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollOffset = (int) Mth.clamp(scrollOffset - verticalAmount * 12, 0, 200);
        return true;
    }

    private void drawRoundedRect(GuiGraphics graphics, int x, int y, int w, int h, int color) {
        graphics.fill(x, y, x + w, y + h, color);
    }

    private void drawBorder(GuiGraphics graphics, int x, int y, int w, int h, int color) {
        graphics.renderOutline(x, y, w, h, color);
    }
}
