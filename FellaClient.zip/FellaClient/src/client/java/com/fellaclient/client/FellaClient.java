package com.fellaclient.client;

import com.fellaclient.client.gui.ClickGuiScreen;
import com.fellaclient.client.module.ModuleManager;
import com.fellaclient.client.module.modules.movement.Sprint;
import com.fellaclient.client.module.modules.render.Fullbright;
import com.fellaclient.client.module.modules.render.FpsDisplay;
import com.fellaclient.client.module.modules.render.Keystrokes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class FellaClient implements ClientModInitializer {
    public static FellaClient INSTANCE;
    public static final String MOD_ID = "fellaclient";
    public static final String MOD_NAME = "FellaClient";

    private KeyMapping openGuiKey;
    private ModuleManager moduleManager;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        moduleManager = new ModuleManager();

        // Register modules
        moduleManager.register(new Sprint());
        moduleManager.register(new Fullbright());
        moduleManager.register(new FpsDisplay());
        moduleManager.register(new Keystrokes());

        // Keybinding for GUI (G key)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.fellaclient.opengui",
                GLFW.GLFW_KEY_G,
                "category.fellaclient"
        ));

        // Tick event for modules and key handling
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClickGuiScreen());
                } else if (client.screen instanceof ClickGuiScreen) {
                    client.setScreen(null);
                }
            }
            moduleManager.onTick();
        });

        // HUD render for modules
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            moduleManager.onHudRender(drawContext, tickCounter.getGameTimeDeltaPartialTick(false));
        });

        System.out.println("[FellaClient] Initialized successfully!");
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }
}
