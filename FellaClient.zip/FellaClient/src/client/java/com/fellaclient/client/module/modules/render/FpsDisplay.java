package com.fellaclient.client.module.modules.render;

import com.fellaclient.client.module.Category;
import com.fellaclient.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;

public class FpsDisplay extends Module {
    public FpsDisplay() {
        super("FPS", "Displays current FPS on screen", Category.RENDER);
    }

    @Override
    public void onHudRender(GuiGraphics graphics, float tickDelta) {
        if (mc.getDebugOverlay() != null) {
            String fps = "FPS: " + mc.getFps();
            graphics.drawString(mc.font, fps, 4, 4, 0x00FF00, true);
        }
    }
}
