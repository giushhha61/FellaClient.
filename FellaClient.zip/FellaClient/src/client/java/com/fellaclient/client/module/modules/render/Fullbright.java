package com.fellaclient.client.module.modules.render;

import com.fellaclient.client.module.Category;
import com.fellaclient.client.module.Module;
import net.minecraft.client.OptionInstance;

public class Fullbright extends Module {
    private double previousGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Makes the world fully bright", Category.VISUALS);
    }

    @Override
    protected void onEnable() {
        if (mc.options != null) {
            OptionInstance<Double> gamma = mc.options.gamma();
            previousGamma = gamma.get();
            gamma.set(16.0); // Max brightness
        }
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) {
            mc.options.gamma().set(previousGamma);
        }
    }

    @Override
    public void onTick() {
        // Keep gamma high while enabled
        if (mc.options != null && isEnabled()) {
            if (mc.options.gamma().get() < 15.0) {
                mc.options.gamma().set(16.0);
            }
        }
    }
}
